<?php

namespace ApiBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Method;

use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\Request;

use Symfony\Component\Serializer\Normalizer\ObjectNormalizer;
use Symfony\Component\Serializer\Encoder\JsonEncoder;
use Symfony\Component\Serializer\Serializer;

use Symfony\Component\Security\Core\Authentication\Token\UsernamePasswordToken;
use Symfony\Component\Security\Core\Authentication\Token\AnonymousToken;

use BlogBundle\Entity\User;
use BlogBundle\Entity\Blog;
use BlogBundle\Entity\Category;
use BlogBundle\Entity\Comment;

// status codes + METHODS  !!!!
//200 OK – [GET]
//201 CREATED – [POST/PUT/PATCH]
//204 NO CONTENT – [DELETE]
//>setAction( $this->generateUrl( 'blog_delete', array('id' => $blog->getId()) ) )
//            ->setMethod('DELETE')

/**
 * Api Blog controller.
 *
 * @Route("/api/blog")
 */
class ApiBlogController extends Controller
{
 
    /**
     * {@inheritdoc}
     */
    public function setDefaultOptions(OptionsResolverInterface $resolver)
    {
        $resolver->setDefaults(array(
            'data_class'        => 'BlogBundle\Entity\Blog',
            'csrf_protection'   => false,
        ));
    }
    
    
    /**
     * Lists all Blog entities.
     *
     * @Route("/", name="api_blog_index")
     * @Method("GET")
     */
    public function indexAction(Request $page)
    {
        $em = $this->getDoctrine()->getManager();
        $total_posts = $em->getRepository('BlogBundle:Blog')->findBy(array('draft'=> 0));
        
        $page = $page->query->getAlnum('page');//get alphanum page val from query !
        if(isset($page) && $page>0){/*norm $page */}else{$page = 1;}
        $limit = 5;
        $maxPages = ceil(count($total_posts) / $limit);
        $thisPage = $page;        
        
        
        
        $blogs = $em->getRepository('BlogBundle:Blog')->findBy(
                                            array('draft'=> 0), //search criteria, as usual, not draft
                                            array(/* orderBy criteria if needed, else empty array */),
                                            $limit, // limit
                                            $limit * ($thisPage - 1) // offset
                                        );
//dump($blogs);
        $norm = new ObjectNormalizer(null);
        $norm->setIgnoredAttributes(array(//must ignore specific datas
            'comments', 'blogComment', 'postComment', 'commentAuthor', 'commentBlog', 'commentContent', //comment blog
            'blogPost', 'categoryBlog', //
            'email', 'emailCanonical', //user email2
            'plainPassword', 'passwordRequestedAt', 'salt', 'credentialsNonExpired', 'superAdmin', 'confirmationToken', //old trashy
            'usernameCanonical', 'roles', 'groups', 'groupNames', '__initializer__', '__cloner__', '__isInitialized__', 'location', 'accountNonExpired', 'accountNonLocked', 'credentialsExpired', 'enabled', 'expired', 'locked', 'user', //secured
            'password',//hide userpassword
            ));
        $norm->setCircularReferenceHandler(function ($object) { return $object->getId();});
        $encoder = new JsonEncoder();
        $serializer = new Serializer(array($norm), array($encoder));

        $ret =  $serializer->serialize( $blogs, 'json');

        ##todo add pager:[page/maxPages/thisPage](now worked on client side)
               // dump($ret);die();
//dump($ret);die();
        return new JsonResponse($ret);
    }

    /**
     * Creates a new Blog entity.
     *
     * @Route("/new", name="api_blog_new")
     * @Method({"GET", "POST"})
     */
    public function newAction(Request $json_content)
    {## send serialized form, API fill them, catch submitted data      

        
        
/* ################# -posted data-

_token        nbhs2IQKlZpjS4XXnZvdZsEeCSLRnNfJ_nt8LcoEEBE
blog_content  asdgdf g dfg
post_category 1
tags	    tag3, tag4, ta6
title	    temp title
setMethod('POST')
####################                    */
// 4 dev  test - recive this 
$json_content = '{"title" : "temp title received from API",
"blog_content" :  "Content for blog from API",
"post_category" :  "1",
"tags" :  "tag1, tag2, tag3, from API"}';



        $ret = json_decode($json_content);
        $em = $this->getDoctrine()->getManager();

        $blog = new Blog();//create empty blog
        $user = $this->get('security.token_storage')->getToken()->getUser();// as $this->getUser();
        // get user from token like this
        $user = $em->getRepository('BlogBundle:User')->find(3);
        //dump($user);die();       
        
        $blog->setPostAuthor($user);//set author of the post
        $blog->setDraft('1');//setting to draft as usual
        
        //set values received from API
        //all required if some missed, it will return error to API
        $blog->setTitle($ret->title);
        $blog->setBlogContent($ret->blog_content);
        
        //get category for category (name or id, it both unique!)
        $ret->post_category = $em->getRepository('BlogBundle:Category')->find($ret->post_category);
        $blog->setPostCategory($ret->post_category);
        $blog->setTags($ret->tags);

        //perform and write to basse
        $em->persist($blog);
        $em->flush();

            #send proper redirect !
            return $this->redirectToRoute( 'api_blog_show', array('id' => $blog->getId()) );
    }

    /** 
     * Finds and displays a Blog entity.
     *
     * @Route("/{id}", name="api_blog_show", requirements={"id": "\d+"})
     * @Route("/{id}/comments", name="api_blog_showcomments", requirements={"id": "\d+"})
     * @Method("GET")
     */
    public function showAction(Blog $blog)
    {
        //dump($blog);die();
        
        $em = $this->getDoctrine()->getManager();

        // getCommentBlog()  by blog id 
        $comments = $em->getRepository('BlogBundle:Comment')
                ->findBy( array('comment_blog' => $blog->getId()) );
                // return all where  comment.commentBlog.id == blog.id

        $norm = new ObjectNormalizer(null);
        $norm->setIgnoredAttributes(array(//must ignore specific datas
            'postCategory', 'blogPost', 'postAuthor','commentBlog', 'blogComment', //remove circular blog
            'email', 'emailCanonical', //user email2
            'plainPassword', 'passwordRequestedAt', 'salt', 'credentialsNonExpired', 'superAdmin', 'confirmationToken', //old trashy
            'usernameCanonical', 'roles', 'groups', 'groupNames', '__initializer__', '__cloner__', '__isInitialized__', 'location', 'accountNonExpired', 'accountNonLocked', 'credentialsExpired', 'enabled', 'expired', 'locked', 'user', //secured
            'password',//hide userpassword
            ));

                
        $norm->setCircularReferenceHandler(function ($object) { return $object->getId();});
        
        $encoder = new JsonEncoder();
        $BlogSerializer = new Serializer(array($norm), array($encoder));

        $jsonOnePost =  $BlogSerializer->serialize( $blog, 'json' );

//dump($jsonOnePost);die();

        return new JsonResponse($jsonOnePost);
    }

    /**
     * Displays a form to edit an existing Blog entity.
     *
     * @Route("/{id}", name="api_blog_edit", requirements={"id": "\d+"})
     * @Method({"PUT"})
     */
    public function editAction(Request $request, Blog $blog)
    {
        
/* ################# -read data from already created blogpost-

_token        nbhs2IQKlZpjS4XXnZvdZsEeCSLRnNfJ_nt8LcoEEBE
blog_content  asdgdf g dfg
post_category 1
tags	    tag3, tag4, ta6
title	    temp title
setMethod('PUT')
####################                    */
// 4 dev  test - recive this 
$json_content = '{"title" : "temp title received from API",
"blog_content" : "Content for blog from API",
"post_category" :  "3",
"tags" : "tag1, tag2, tag3, from API"}';

        $ret = json_decode($json_content);
        $em = $this->getDoctrine()->getManager();
        
       
        //change values if it setted from API !
        if( isset($ret->title) ){ $blog->setTitle($ret->title); }
        if( isset($ret->blog_content) ){ $blog->setBlogContent($ret->blog_content); }
        if( isset($ret->post_category) ){ 
            $ret->post_category = $em->getRepository('BlogBundle:Category')->find($ret->post_category);
            $blog->setPostCategory($ret->post_category); }
        if( isset($ret->tags) ){ $blog->setTags($ret->tags); }

//dump($blog);die();

        //perform and write to basse
        $em->persist($blog);
        $em->flush();

            #send proper redirect !
            return $this->redirectToRoute( 'api_blog_show', array('id' => $blog->getId()) );

    }

    /**
     * Deletes a Blog entity.
     *
     * @Route("/{id}", name="api_blog_delete", requirements={"id": "\d+"})
     * @Method("DELETE")
     */
    public function deleteAction(Request $request, Blog $blog)
    {
        
        //dump($blog);die("Deleted !!!!");
        $em = $this->getDoctrine()->getManager();
        $em->remove($blog);
        $em->flush();

        return $this->redirectToRoute('api_blog_index');
    }
 

    
  /**
     * WSSE Token Remover
     *
     * @return Default blog
     */
    public function logoutGetTokenDestroyAction()
    {
        $security = $this->get('security.context');
        $token = new AnonymousToken(null, new User());
        $security->setToken($token);
        $this->get('session')->invalidate();
        ////return redirect to main blog !!!!!!!!!!!!!!!!!!
        return $this->redirectToRoute('api_blog_index');
    }
    
    
 

}