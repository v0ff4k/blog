<?php

namespace ApiBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Method;

use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\Request;

use Symfony\Component\Serializer\Normalizer\ObjectNormalizer;
use Symfony\Component\Serializer\Encoder\JsonEncoder;
use Symfony\Component\Serializer\Serializer;

use Symfony\Component\Security\Core\Authentication\Token\UsernamePasswordToken;
use Symfony\Component\Security\Core\Authentication\Token\AnonymousToken;

use BlogBundle\Entity\User;
use BlogBundle\Entity\Blog;
use BlogBundle\Entity\Category;
use BlogBundle\Entity\Comment;

// status codes + METHODS  !!!!
//200 OK – [GET]
//201 CREATED – [POST/PUT/PATCH]
//204 NO CONTENT – [DELETE]
//>setAction( $this->generateUrl( '_delete', array('id' => $entity->getId()) ) )
//            ->setMethod('DELETE')

/**
 * Api Category controller.
 *
 * @Route("/api/category")
 */
class ApiCategoryController extends Controller
{
 
    /**
     * {@inheritdoc}
     */
    public function setDefaultOptions(OptionsResolverInterface $resolver)
    {
        $resolver->setDefaults(array(
            'data_class'        => 'BlogBundle\Entity\Category',
            'csrf_protection'   => false,
        ));
    }
    
    
    /**
     * Lists all Category entities.
     *
     * @Route("/", name="api_category_index")
     * @Method("GET")
     */
    public function indexAction(Request $page)
    {
        $em = $this->getDoctrine()->getManager();
        $categories = $em->getRepository('BlogBundle:Category')->findAll();
        
        

//dump($categories);
        $norm = new ObjectNormalizer(null);
        $norm->setIgnoredAttributes(array(//must ignore specific datas
            'comments', 
            'categoryBlog', // not in category
            'plainPassword', 'passwordRequestedAt', 'salt', 'credentialsNonExpired', 'superAdmin', 'confirmationToken', //old trashy
            'usernameCanonical', 'roles', 'groups', 'groupNames', '__initializer__', '__cloner__', '__isInitialized__', 'location', 'accountNonExpired', 'accountNonLocked', 'credentialsExpired', 'enabled', 'expired', 'locked', 'user', //secured
            'password',//hide userpassword
            ));
        $norm->setCircularReferenceHandler(function ($object) { return $object->getId();});
        $encoder = new JsonEncoder();
        $serializer = new Serializer(array($norm), array($encoder));

        $ret =  $serializer->serialize( $categories, 'json');

        ##todo add pager:[page/maxPages/thisPage](now worked on client side)
               // dump($ret);die();
//dump($ret);die();
        return new JsonResponse($ret);
    }

    /**
     * Creates a new Category entity.??????????????????????????
     *
     * @Route("/new", name="api_category_new")
     * @Method({"GET", "POST"})
     */
    public function newAction(Request $json_content)
    {## send serialized form, API fill them, catch submitted data      

        
        
/* ################# -posted data-

_token        nbhs2IQKlZpjS4XXnZvdZsEeCSLRnNfJ_nt8LcoEEBE
category_name  Some category name
setMethod('POST')
####################                    */
// 4 dev  test - recive this 
$json_content = '{"category_name" : "Some new category"}';


        $ret = json_decode($json_content);
        $em = $this->getDoctrine()->getManager();

//dump($json_content);die();

       $category = new Category();//create empty Category
        $user = $this->get('security.token_storage')->getToken()->getUser();// as $this->getUser();
        // get user from token like this
        $user = $em->getRepository('BlogBundle:User')->find(3);
        //dump($user);die();       
       
        //set values received from API
        $category->setCategoryName($ret->category_name);
        
        //perform and write to basse
        $em->persist($category);
        $em->flush();

            #send proper redirect !
            return $this->redirectToRoute( 'api_category_index' );
    }

    /** 
     * Finds and displays a Category entity.
     *
     * @Route("/{id}", name="api_category_show", requirements={"id": "\d+"})
     * @Route("/{id}/posts", name="api_category_showposts", requirements={"id": "\d+"})
     * @Method("GET")
     */
    public function showAction(Category $category, Request $page)
    {
        //dump($category);die();
        
        $em = $this->getDoctrine()->getManager();
        $total_posts = $em->getRepository('BlogBundle:Blog')->findBy( array(
                    'draft'=> 0, 
                    'post_category' => $category->getId() 
                ) );
        
        
        //dump($total_posts);die();
        $page = $page->query->getAlnum('page');
        if(isset($page) && $page>0){/*norm $page */}else{$page = 1;}
        $limit = 5;
        $maxPages = round(count($total_posts) / $limit);
        $thisPage = $page;  
        
        $blogs = $em->getRepository('BlogBundle:Blog')->findBy(
                                            array('draft'=> 0, //search criteria, as usual, not draft
                    'post_category' => $category->getId()), //and for current category
                                            array(/* orderBy criteria if needed, else empty array */),
                                            $limit, // limit
                                            $limit * ($thisPage - 1) // offset
                                        );

        //dump($blogs);
        //dump($category);die();

        $norm = new ObjectNormalizer(null);
        $norm->setIgnoredAttributes(array(//must ignore specific datas
            'postComment', 'postCategory',   //remove circular comments and categories
            'blogPost', 'blogComment', //remove circular blog
            'usernameCanonical', 'email', 'emailCanonical', //user email2
            'plainPassword', 'passwordRequestedAt', 'salt', 'credentialsNonExpired', 'superAdmin', 'confirmationToken', //old trashy
            'roles', 'groups', 'groupNames', '__initializer__', '__cloner__', '__isInitialized__', 'location', 'accountNonExpired', 'accountNonLocked', 'credentialsExpired', 'enabled', 'expired', 'locked', 'user', //secured
            'password',//hide userpassword
            ));

                
        $norm->setCircularReferenceHandler(function ($object) { return $object->getId();});
        
        $encoder = new JsonEncoder();
        $BlogSerializer = new Serializer(array($norm), array($encoder));

        $jsonOnePost =  $BlogSerializer->serialize( $blogs, 'json' );
        
//dump($jsonOnePost);die();

        return new JsonResponse($jsonOnePost);
    }

    /**
     * Displays a form to edit an existing Category entity.
     * 
     * @Route("/{id}", name="api_category_edit", requirements={"id": "\d+"})
     * @Route("/{id}/put", name="api_category_put", requirements={"id": "\d+"})
     * @Method({"PUT"})
     */
    public function editAction(Request $request, Category $category)
    {
        
/* ################# -read data from already created blogpost-

_token        nbhs2IQKlZpjS4XXnZvdZsEeCSLRnNfJ_nt8LcoEEBE
category_name  Some updated category
setMethod('PUT')
####################                    */
// 4 dev  test - recive this 
$json_content = '{"category_name" : "Some new category"}';

        $ret = json_decode($json_content);
        $em = $this->getDoctrine()->getManager();
        
        //set values received from API
        $category->setCategoryName($ret->category_name);

//dump($category);die();

        //perform and write to basse
        $em->persist($category);
        $em->flush();

            #send proper redirect !
            return $this->redirectToRoute( 'api_category_index' );

    }

    /**
     * Deletes a Category entity.
     *
     * @Route("/{id}", name="api_category_delete", requirements={"id": "\d+"})
     * @Method("DELETE")
     */
    public function deleteAction(Request $request, Category $category)
    {
        
        //dump($category);die("Deleted !!!!");
        $em = $this->getDoctrine()->getManager();
        $em->remove($category);
        $em->flush();

        return $this->redirectToRoute('api_category_index');
    }
 

    
  /**
     * WSSE Token Remover
     *
     * @return Default blog
     */
    public function logoutGetTokenDestroyAction()
    {
        $security = $this->get('security.context');
        $token = new AnonymousToken(null, new User());
        $security->setToken($token);
        $this->get('session')->invalidate();
        ////return redirect to main blog !!!!!!!!!!!!!!!!!!
        return $this->redirectToRoute('api_blog_index');
    }
    
    
 

}