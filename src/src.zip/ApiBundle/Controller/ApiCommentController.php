<?php

namespace ApiBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Method;

use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\Request;

use Symfony\Component\Serializer\Normalizer\ObjectNormalizer;
use Symfony\Component\Serializer\Encoder\JsonEncoder;
use Symfony\Component\Serializer\Serializer;

use Symfony\Component\Security\Core\Authentication\Token\UsernamePasswordToken;
use Symfony\Component\Security\Core\Authentication\Token\AnonymousToken;

use BlogBundle\Entity\User;
use BlogBundle\Entity\Blog;
use BlogBundle\Entity\Category;
use BlogBundle\Entity\Comment;

// status codes + METHODS  !!!!
//200 OK – [GET]
//201 CREATED – [POST/PUT/PATCH]
//204 NO CONTENT – [DELETE]
//>setAction( $this->generateUrl( 'blog_delete', array('id' => $blog->getId()) ) )
//            ->setMethod('DELETE')

/**
 * Api Comment controller.
 *
 * @Route("/api/comment")
 */
class ApiCommentController extends Controller
{
 
    /**
     * {@inheritdoc}
     */
    public function setDefaultOptions(OptionsResolverInterface $resolver)
    {
        $resolver->setDefaults(array(
            'data_class'        => 'BlogBundle\Entity\Comment',
            'csrf_protection'   => false,
        ));
    }
    
    
    /**
     * Lists all Comment entities with their commentBlog datas.
     *
     * @Route("/", name="api_comment_index")
     * @Method("GET")
     */
    public function indexAction(Request $page)
    {
        $emr = $this->getDoctrine()->getManager()->getRepository('BlogBundle:Comment');
        $total_comments = $emr->findAll();
        
        $page = $page->query->getAlnum('page');//get alphanum page val from query !
        if(isset($page) && $page>0){/*norm $page */}else{$page = 1;}
        $limit = 3;//1 for dev test
        $maxPages = ceil(count($total_comments) / $limit);
        $thisPage = $page;        
        
        
        
        $comments = $emr->findBy(
                                            array(/*search all, without criteria*/),
                                            array('postDate' => 'DESC'),
                                            $limit, // limit
                                            $limit * ($thisPage - 1) // offset
                                        );
//dump($comments);die();
        $norm = new ObjectNormalizer(null);
        $norm->setIgnoredAttributes( array(//must ignore specific datas
            'blogPost', 'postComment', 'postComment', 'blogComment', 'postCategory', '', 
            'email', 'emailCanonical', //user email2
            'password', 'plainPassword', 'passwordRequestedAt', 'salt', 'credentialsNonExpired', 'superAdmin', 'confirmationToken', //old trashy
            'usernameCanonical', 'roles', 'groups', 'groupNames', '__initializer__', '__cloner__', '__isInitialized__', 'location', 'accountNonExpired', 'accountNonLocked', 'credentialsExpired', 'enabled', 'expired', 'locked', 'user', //secured
            ) );
        $norm->setCircularReferenceHandler(function ($object) { return $object->getId();});
        $encoder = new JsonEncoder();
        $serializer = new Serializer(array($norm), array($encoder));

        $ret =  $serializer->serialize( $comments, 'json');

        ##todo add pager:[page/maxPages/thisPage](now worked on client side)
               // dump($ret);die();

        return new JsonResponse($ret);
    }

    /**
     * Creates a new Comment entity for blog.id.
     *
     * @Route("/new/{id}", name="api_comment_new", requirements={"id": "\d+"})
     * @Method({"GET", "POST"})
     */
    public function newAction(Request $json_content, Blog $blog)
    {## send serialized form, API fill them, catch submitted data      

/* ################# -posted data-
_token        nbhs2IQKlZpjS4XXnZvdZsEeCSLRnNfJ_nt8LcoEEBE
comment_content  content of new comment for blog.id
setMethod('POST')
####################                    */
// 4 dev  test - recive this 
$json_content = '{"comment_content" : "content of new comment for blog.id"}';

        $ret = json_decode($json_content);
        $em = $this->getDoctrine()->getManager();

        $comment = new Comment();//create empty comment
        $comment->setCommentBlog($blog);//for one blogpost
        
        $user = $this->get('security.token_storage')->getToken()->getUser();// as $this->getUser();
        // get user from token like this  4dev test
        $user = $em->getRepository('BlogBundle:User')->find(3);
        //dump($user);die();       

        
        //set values received from API
        //all required if some missed, it will return error to API
        $comment->setCommentAuthor($user);
        $comment->setCommentContent($ret->comment_content);

//dump($ret);dump($comment);die();        
        
        //perform and write to basse
        $em->persist($comment);
        $em->flush();

            #send proper redirect !
            return $this->redirectToRoute( 'api_blog_show', array('id' => $blog->getId()) );
    }

    /** 
     * Finds and displays 1 Comment entity bu id.
     *
     * @Route("/{id}", name="api_comment_show", requirements={"id": "\d+"})
     * @Method("GET")
     */
    public function showAction(Comment $comment)
    {
        //dump($comment);die();
        
        $em = $this->getDoctrine()->getManager();

        // getCommentBlog()  by blog id 
//        $comment = $em->getRepository('BlogBundle:Comment')
//                ->findBy( array('comment_blog' => $blog->getId()) );
//                // return all where  comment.commentBlog.id == blog.id

        $norm = new ObjectNormalizer(null);
        $norm->setIgnoredAttributes(array(//must ignore specific datas
            'blogPost', 'postComment', 'postComment', 'blogComment', 'postCategory', '', 
            'email', 'emailCanonical', //user email2
            'password', 'plainPassword', 'passwordRequestedAt', 'salt', 'credentialsNonExpired', 'superAdmin', 'confirmationToken', //old trashy
            'usernameCanonical', 'roles', 'groups', 'groupNames', '__initializer__', '__cloner__', '__isInitialized__', 'location', 'accountNonExpired', 'accountNonLocked', 'credentialsExpired', 'enabled', 'expired', 'locked', 'user', //secured
           ));

                
        $norm->setCircularReferenceHandler(function ($object) { return $object->getId();});
        
        $encoder = new JsonEncoder();
        $CommentSerializer = new Serializer(array($norm), array($encoder));

        $jsonOnePost =  $CommentSerializer->serialize( $comment, 'json' );

//dump($jsonOnePost);die();

        return new JsonResponse($jsonOnePost);
    }

    /**
     * Displays a form to edit an existing Comment entity.
     *
     * @Route("/{id}", name="api_comment_edit", requirements={"id": "\d+"})
     * @Method({"PUT"})
     */
    public function editAction(Request $request, Blog $blog)
    {
        
/* ################# -read data from already created blogpost-

_token        nbhs2IQKlZpjS4XXnZvdZsEeCSLRnNfJ_nt8LcoEEBE
id #11
 comment_content  ontent of new comment for blog.id
setMethod('PUT')
####################                    */
// 4 dev  test - recive this 
$json_content = '{"title" : "temp title received from API",
"blog_content" : "Content for blog from API",
"post_category" :  "3",
"tags" : "tag1, tag2, tag3, from API"}';

        $ret = json_decode($json_content);
        $em = $this->getDoctrine()->getManager();
        
       
        //change values if it setted from API !
        if( isset($ret->title) ){ $blog->setTitle($ret->title); }
        if( isset($ret->blog_content) ){ $blog->setBlogContent($ret->blog_content); }
        if( isset($ret->post_category) ){ 
            $ret->post_category = $em->getRepository('BlogBundle:Category')->find($ret->post_category);
            $blog->setPostCategory($ret->post_category); }
        if( isset($ret->tags) ){ $blog->setTags($ret->tags); }

//dump($blog);die();

        //perform and write to basse
        $em->persist($blog);
        $em->flush();

            #send proper redirect !
            return $this->redirectToRoute( 'api_blog_show', array('id' => $blog->getId()) );

    }

    /**
     * Deletes a Comment entity.
     *
     * @Route("/{id}", name="api_comment_delete", requirements={"id": "\d+"})
     * @Method("DELETE")
     */
    public function deleteAction(Request $request, Blog $blog)
    {
        
        //dump($blog);die("Deleted !!!!");
        $em = $this->getDoctrine()->getManager();
        $em->remove($blog);
        $em->flush();

        return $this->redirectToRoute('api_blog_index');
    }
 

    
  /**
     * WSSE Token Remover
     *
     * @return Default blog
     */
    public function logoutGetTokenDestroyAction()
    {
        $security = $this->get('security.context');
        $token = new AnonymousToken(null, new User());
        $security->setToken($token);
        $this->get('session')->invalidate();
        ////return redirect to main blog !!!!!!!!!!!!!!!!!!
        return $this->redirectToRoute('api_blog_index');
    }
    
    
 

}