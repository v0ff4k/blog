<?php

namespace ApiBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;

use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\Request;

class DefaultController extends Controller
{
    /**
     * @Route("/api/", name="apihome")
     */
    public function indexAction()
    {        //dump($this);die();
        return $this->render('ApiBundle:Default:index.html.twig');
    }

    /** {{ path('gimmesalt', { 'username': 'admin' } ) }}
     * @Route("/{username}/salt", requirements={"username" = "\w+"}, name="gimmesalt")
     */
    public function saltAction($username)
    {
        $userManager = $this->container->get('fos_user.user_manager');

        $user = $userManager->findUserByUsername($username);
        if ( is_null($user) )
        {
            return new Response("Error User Not Found");
        }

        //next just resend salt !
        return new Response($user->getSalt());
    }


}