<?php // src/ApiBundle/DependencyInjection/Security/Factory/WsseFactory.php
namespace ApiBundle\DependencyInjection\Security\Factory;

use Symfony\Component\DependencyInjection\ContainerBuilder;
use Symfony\Component\DependencyInjection\Reference;
use Symfony\Component\DependencyInjection\DefinitionDecorator;
use Symfony\Component\Config\Definition\Builder\NodeDefinition;
use Symfony\Bundle\SecurityBundle\DependencyInjection\Security\Factory\SecurityFactoryInterface;

class WsseFactory implements SecurityFactoryInterface
{
    public function create(ContainerBuilder $container, $id, $config, $userProvider, $defaultEntryPoint)
    {
        $providerId = 'security.authentication.provider.wsse.'.$id;
        $container
            ->setDefinition($providerId, new DefinitionDecorator('wsse.security.authentication.provider'))
            ->replaceArgument(0, new Reference($userProvider))
            //->replaceArgument(1, new DefinitionDecorator('fos_user.user_manager'))
        ;

        $listenerId = 'security.authentication.listener.wsse.'.$id;
        $listener = $container->setDefinition($listenerId, new DefinitionDecorator('wsse.security.authentication.listener'));

        return array($providerId, $listenerId, $defaultEntryPoint);
    }

    public function getPosition()
    {
        return 'pre_auth';
    }

    public function getKey()
    {
        return 'wsse';
    }

    public function addConfiguration(NodeDefinition $node)
    {
     // add life time for 5 min
    $node
        ->children()
        ->scalarNode('lifetime')->defaultValue(300)->end();
    $node
        ->children()
        ->scalarNode('date_format')->defaultValue('/^([\+-]?\d{4}(?!\d{2}\b))((-?)((0[1-9]|1[0-2])(\3([12]\d|0[1-9]|3[01]))?|W([0-4]\d|5[0-2])(-?[1-7])?|(00[1-9]|0[1-9]\d|[12]\d{2}|3([0-5]\d|6[1-6])))([T\s]((([01]\d|2[0-3])((:?)[0-5]\d)?|24\:?00)([\.,]\d+(?!:))?)?(\17[0-5]\d([\.,]\d+)?)?([zZ]|([\+-])([01]\d|2[0-3]):?([0-5]\d)?)?)?)?$/')      
        ->end();
    $node
        ->children()
        ->scalarNode('realm')->defaultValue('Secured with WSSE') 
            #identifies the set of resources to which the authentication information will apply (WWW-Authenticate)   
        ->end();
    $node
        ->children()
        ->scalarNode('profile')->defaultValue('UsernameToken')   
           #WSSE profile (WWW-Authenticate)
        ->end();
    $node
        ->children()
        ->scalarNode('encoder')->defaultValue('{algorithm: bcrypt, cost: 13, encodeHashAsBase64: true, iterations: 1}')   
           #WSSE encoder pack      MUST BE EXACTLY AS 'algorithm' in config of FOS userBundle !!!!!!!!!!!!!!!!
        ->end();
    $node
        ->children()
        ->scalarNode('nonce_cache_service_id')->defaultValue('cache_nonces')->end();
    $node
        ->children()
        ->scalarNode('anonymous ')->defaultValue('false')->end();
    }
}