<?php // src/ApiBundle/Security/Authentication/Provider/WsseProvider.php
namespace ApiBundle\Security\Authentication\Provider;

use Symfony\Component\Security\Core\Authentication\Provider\AuthenticationProviderInterface;
use Symfony\Component\Security\Core\User\UserProviderInterface;
use Symfony\Component\Security\Core\Exception\AuthenticationException;
use Symfony\Component\Security\Core\Exception\NonceExpiredException;
use Symfony\Component\Security\Core\Authentication\Token\TokenInterface;
use ApiBundle\Security\Authentication\Token\WsseUserToken;
//use Symfony\Component\Security\Core\User\UserInterface;

class WsseProvider implements AuthenticationProviderInterface
{
    private $userProvider;
    private $cacheDir;
    //private $encoderFactory;

    public function __construct(UserProviderInterface $userProvider, $cacheDir)
    {
        //$this->encoderFactory = $encoderFactory; 
        $this->userProvider = $userProvider;
        $this->cacheDir     = $cacheDir;
    }

    public function authenticate(TokenInterface $token)
    {  

//dump($token);//die();
        $user = $this->userProvider->loadUserByUsername($token->getUsername());
//dump($user);//die("USEEEEEEEEER !!!!!!!!!!!!");//gets user from DB !!!
        
//dump( $this->validateDigest($token->digest, $token->nonce, $token->created, $user ) );

//die("PROVIDER ------------- validateDigest-------------------------");

        if ($user && 
            $this->validateDigest( $token->digest, $token->nonce, $token->created, $user->getPassword() ) 
            ) {
            $authenticatedToken = new WsseUserToken($user->getRoles());
            $authenticatedToken->setUser($user);

            return $authenticatedToken;
        }

        throw new AuthenticationException('The WSSE authentication failed.');
    }

    /**
     * This function is specific to Wsse authentication and is only used to help this example
     *
     * For more information specific to the logic here, see
     * https://github.com/symfony/symfony-docs/pull/3134#issuecomment-27699129
     */
    protected function validateDigest($digest, $nonce, $created, $secret)
    {
        
     
//dump( $created, date("c"));die();
//dump( strtotime($created) > time() );die();
        // Check created time is not in the future
        if ( strtotime($created) > time() ) {
            return false;
        }

        // Expire timestamp after 5 minutes
        if (time() - strtotime($created) > 300) {
            return false;
        }

        // Validate that the nonce is *not* used in the last 5 minutes
        // if it has, this could be a replay attack
        if (
            file_exists($this->cacheDir.'/'.md5($nonce)) && 
            file_get_contents($this->cacheDir.'/'.md5($nonce)) + 300 > time()
        ) {
            throw new NonceExpiredException('Previously used nonce detected');
        }
        // If cache directory does not exist we create it
        if (!is_dir($this->cacheDir)) {
            mkdir($this->cacheDir, 0777, true);
        }
        file_put_contents($this->cacheDir.'/'.md5($nonce), time());

        // Validate Secret
        $expected = base64_encode(sha1(base64_decode($nonce).$created.$secret, true));
        

//dump($expected, $digest);//die("EEEEEEEEEEEEEEEEEE");

        return hash_equals($expected, $digest);

    }

    public function supports(TokenInterface $token)
    {
        return $token instanceof WsseUserToken;
    } 
}
