<?php // src/BlogBundle/Admin/BlogAdmin.php

namespace BlogBundle\Admin;

use Sonata\AdminBundle\Admin\AbstractAdmin;
use Sonata\AdminBundle\Datagrid\ListMapper;
use Sonata\AdminBundle\Datagrid\DatagridMapper;
use Sonata\AdminBundle\Form\FormMapper;

use Sonata\AdminBundle\Validator\ErrorElement;
use Sonata\AdminBundle\Route\RouteCollection;

use Symfony\Component\Form\Extension\Core\Type\TextareaType;

class BlogAdmin extends AbstractAdmin
{
    // make custom sort page
     protected $datagridValues = array(

        // display the first page (default = 1)
        '_page' => 1, //1st page will display 1st

        // reverse order (default = 'ASC')
        '_sort_order' => 'DESC', //newest 1st

        // name of the ordered field (default = the model's id field, if any)
        '_sort_by' => 'postDate', //by post date
    );
     
//    //publish current post  are in //src/BlogBundle/Controller/Publish.php
//    public function update($id)
//    {
//        
//        $em = $this->getDoctrine()->getManager();
//        
//       dump($id);dump($em);die("ACTION !!!!!!!!!!!!!!!!!!!!!!!"); 
//
//        foreach ($selectedModelQuery->execute() as $posts){
//            
//            if($posts->getDraft()){ //if post is a draft - so make them undraft
//            $posts->setDraft('0');
//            $em->persist($posts);
//            }
//        }
//        
//        $em->flush();
//        
//        return new RedirectResponse(
//            $this->admin->generateUrl('list', array('filter' => $this->admin->getFilterParameters()))
//        );
//
//    }
     
     
    /**
     * @param RouteCollection $collection
     */
    // remove delete button
    protected function configureRoutes(RouteCollection $collection)
    {   // RouteCollection($baseCodeRoute, $baseRouteName, $baseRoutePattern, $baseControllerName)
        
        $collection
            //hide unessisary delete, couse we got it in batch
            ->remove('delete')
            //add big FAST 'publish' button
            ->add('publish',
                 $this->getRouterIdParameter().'/publish',
                array('_controller' => 'BlogBundle:CRUD:publish')
            )
// manual to add !!!
// $collection->add(
// $name, 
//  $pattern = null, 
//   array $defaults = array(), 
//    array $requirements = array(), 
//     array $options = array(), 
//      $host = (', 
//       array $schemes = array(), 
//        array $methods = array(), 
//         $condition = '');
        ;

    }
     
    
    //batch publish 
    /**
     * {@inheritdoc}
     */
    public function getBatchActions()
    {
        $actions = parent::getBatchActions();

        $actions['delete'] = array(
            'label' => $this->getLabelTranslatorStrategy()->getLabel('Delete'),
            'translation_domain' => $this->getTranslationDomain(),
            'ask_confirmation' => true,
        );
        
        $actions['publish'] = array(
            'label' => $this->getLabelTranslatorStrategy()->getLabel('Publish'),
            'translation_domain' => $this->getTranslationDomain(),
            'ask_confirmation' => false,
        );
        $actions['drafter'] = array(
            'label' => $this->getLabelTranslatorStrategy()->getLabel('Draft'),
            'translation_domain' => $this->getTranslationDomain(),
            'ask_confirmation' => false,
        );
        return $actions;
    }
    
     
    /**
     * {@inheritdoc}
     */
    protected function configureFormFields(FormMapper $formMapper)
    { //die("formMapper");// blog/blog/create(edit)
        $formMapper
                ->add('title', 'text', array('label' => 'Title'))
                ->add('blog_content', TextareaType::class, array('label' => 'Content'))
                //show for EDIT !!!!
                ->add('tags', 'text')
                ->add('post_author', null, array('label' => 'Author of blog'))
                ->add('post_category', null, array('label' => 'Category for blog'))
                ->add('draft', 'choice', array(
                        'choices' => array('1' => 'Draft', '0' => 'Published')
                    ))//////////////////////////////////////////////////make button PUBLISH !!!!!!!!!!!!!!
                ->add('postDate', 'datetime', array(
                    'format' => 'd/m/Y H:i',
                    'label' => 'Posted'))
                ;
    }
    
    /**
     * @param DatagridMapper $filter
     */
    protected function configureDatagridFilters(DatagridMapper $datagridMapper)
    {//die("datagridMapper");//  after  -  blog/blog/list
        $datagridMapper
                ->add('id')
                ->add('title', null, array('label' => 'Title'))
                ->add('blog_content', null, array('label' => 'Content'))
                //show for search by content !!!!
                ->add('tags', null)
                ->add('post_author', null, array('label' => 'Author of blog'))
                ->add('post_category', null, array('label' => 'Category for blog'))
                ->add('draft', null, array('label' => 'Daft') )
                ;
    }
    
    /**
     * @param ListMapper $list
     */
    protected function configureListFields(ListMapper $listMapper)
    {//die("listMapper");// blog/blog/list
        
        $listMapper
                ->addIdentifier('id', null, array( 'label' => 'ID', 'header_style' => 'width: 5px;'))
                ->addIdentifier('post_author', 'text', array('label' => 'Author'))
                ->addIdentifier('title', 'text', array('label' => 'Title'))
                //->addIdentifier('blog_content', 'text', array('label' => 'Content'))
                //hidden couse might overload admin page !!!!
                ->addIdentifier('tags')
                ->addIdentifier('post_category.category_name', null, array('label' => 'Category'))
                ->addIdentifier('postDate', 'datetime', array(
                    'format' => 'd/m/Y H:i',
                    'label' => 'Posted'))
                ->addIdentifier('draft', 'choice', array(
                        'label' => 'Draft state',
                        'editable' => true,
                        'choices' => array('1' => 'Draft', '0' => 'Published')
                    ))
                ;
    }
    // array( ... ’delete’ => array (’template’ => ’MyBundle:MyController:my_partial.html.twig’)

}
























