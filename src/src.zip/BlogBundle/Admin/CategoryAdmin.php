<?php // src/AppBundle/Admin/CategoryAdmin.php
namespace BlogBundle\Admin;

use Sonata\AdminBundle\Admin\AbstractAdmin;
use Sonata\AdminBundle\Datagrid\ListMapper;
use Sonata\AdminBundle\Datagrid\DatagridMapper;
use Sonata\AdminBundle\Form\FormMapper;

class CategoryAdmin extends AbstractAdmin
{
    protected function configureFormFields(FormMapper $formMapper)
    { //die("formMapper");// blog/category/create
        $formMapper->add('category_name', 'text', array('label' => 'Category name'));
    }

    protected function configureDatagridFilters(DatagridMapper $datagridMapper)
    {//die("datagridMapper");//  after  -  blog/category/list
        $datagridMapper
                ->add('id')
                ->add('category_name', null, array('label' => 'Category name'))
                ;
    }

    protected function configureListFields(ListMapper $listMapper)
    {//die("listMapper");// blog/category/list
        
        $listMapper->addIdentifier('id', 'text', array(
            'label' => '# id',
            'header_style' => 'width: 10%; text-align: center',
            'row_align' => 'center'))
                ->addIdentifier('category_name', 'text', array('label' => 'Category name'))
                ;
    }
    
    
}