<?php // src/AppBundle/Admin/CommentAdmin.php
namespace BlogBundle\Admin;

use Sonata\AdminBundle\Admin\AbstractAdmin;
use Sonata\AdminBundle\Datagrid\ListMapper;
use Sonata\AdminBundle\Datagrid\DatagridMapper;
use Sonata\AdminBundle\Form\FormMapper;

use Symfony\Component\Form\Extension\Core\Type\TextareaType;

class CommentAdmin extends AbstractAdmin
{
    protected function configureDatagridFilters(DatagridMapper $datagridMapper)
    {//die("datagridMapper");//  after  -  blog/category/list
        $datagridMapper
                ->add('id', null, array('label' => 'comment id '))
                ->add('comment_blog.post_author.name', null, array( 'label' => 'Author of comment') )
                ->add('comment_content', null, array('label' => 'Comment content'))
                ->add('comment_blog.title', null, array( 'label' => 'for Blog title' ) )
                ->add('comment_blog.id', null, array( 'label' => 'for Blog id' ) )
                ;
    }

    protected function configureListFields(ListMapper $listMapper)
    {//die("listMapper");// blog/category/list
        $listMapper
                ->addIdentifier('id', 'text', array('label' => '#'))
                ->addIdentifier('comment_blog.post_author.name', 'many_to_one', array( 'label' => 'Author of comment') )
                ->addIdentifier('comment_content', 'text', array('label' => 'Comment content'))
                ->addIdentifier('comment_blog.title', 'many_to_one', array( 'label' => 'for Blog title' ) )
                ->addIdentifier('comment_blog.id', 'many_to_one', array( 'label' => 'for Blog id' ) )
                ->addIdentifier('postDate','datetime',array( 'format' => 'd/m/Y H:i', 
                                                                  'label' => 'Post date') )
                ;
    }
  
    protected function configureFormFields(FormMapper $formMapper)
    { //die("formMapper");// blog/category/create
        $formMapper
                ->add('comment_content', TextareaType::class, array('label' => 'Comment content'))
                ->add('comment_blog', null, array( 'label' => 'Comment for blog(title)' ) )
                ->add('comment_author', null, array( 'label' => 'Comment by user(name)' ) )
                ->add('postDate','datetime',array( 'label' => 'Comment date and time') )
                ;
    }

    
}