<?php // src/AppBundle/Admin/UserAdmin.php
namespace BlogBundle\Admin;

use Sonata\AdminBundle\Admin\AbstractAdmin;
use Sonata\AdminBundle\Datagrid\ListMapper;
use Sonata\AdminBundle\Datagrid\DatagridMapper;
use Sonata\AdminBundle\Form\FormMapper;

class SubscribeAdmin extends AbstractAdmin
{
    
    protected function configureFormFields(FormMapper $formMapper)
    { //die("formMapper");// blog/category/create
       
 
        $formMapper
                ->add('subscriber', 'text', array('label' => 'Real Name'))
                ->add('email', 'text', array('label' => 'E-mail'))
                ;
    }
    
    

    protected function configureDatagridFilters(DatagridMapper $datagridMapper)
    {//die("datagridMapper");//  after  -  blog/category/list
        $datagridMapper
                ->add('subscriber', null, array('label' => 'Real Name'))
                ->add('email', null, array('label' => 'E-mail'))
                ;
    }

    protected function configureListFields(ListMapper $listMapper)
    {//die("listMapper");// blog/category/list
        
        $listMapper
                ->addIdentifier('subscriber', 'text', array('label' => 'Username'))
                ->addIdentifier('email', 'text', array('label' => 'E-mail'))
                ;
    }
//  possible types: in ->add*(cel_from_entyty, type, array_options)
//    boolean,
//    datetime,
//    decimal,
//    identifier,
//    integer,
//    many_to_one,
//    string,
//    text,
//    date,
//    time,
//    array.
    
    
}