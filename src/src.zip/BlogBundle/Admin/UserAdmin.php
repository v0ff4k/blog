<?php // src/AppBundle/Admin/UserAdmin.php
namespace BlogBundle\Admin;

use Sonata\AdminBundle\Admin\AbstractAdmin;
use Sonata\AdminBundle\Datagrid\ListMapper;
use Sonata\AdminBundle\Datagrid\DatagridMapper;
use Sonata\AdminBundle\Form\FormMapper;

use Symfony\Component\Validator\Constraints as Assert;

use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\Extension\Core\Type\CheckboxType;

class UserAdmin extends AbstractAdmin
{
    
    public function preUpdate($object)
    {
        $DM = $this->getConfigurationPool()->getContainer()->get('Doctrine')->getManager();
        $repository = $DM->getRepository('BlogBundle\Entity\User')->find($object->getId());

        $Password = $object->getPassword();
        if (!empty($Password)) {
            $salt = md5(time());

            $encoderservice = $this->getConfigurationPool()->getContainer()->get('security.encoder_factory');
            $encoder = $encoderservice->getEncoder($object);
            $encoded_pass = $encoder->encodePassword($object->getPassword(), $salt);
            $object->setSalt($salt);
            $object->setPassword($encoded_pass);
        } else {
            $object->setPassword($repository->getPassword());
        }
    }
    
    protected function configureFormFields(FormMapper $formMapper)
    { //die("formMapper");// blog/category/create
       
        $passwordoptions=array(
            'type' => 'password','invalid_message' => 'The password fields must match.',
            'options' => array( 'attr' => array('class' => 'password-field') ),
            'first_options' => array('label' => 'Password'),
            'second_options' => array('label' => 'Confirm password'),'translation_domain' => 'FOSUserBundle'
               );

        $this->record_id = $this->request->get($this->getIdParameter());
         if (!empty($this->record_id)) {
             $passwordoptions['required'] = false;
             $passwordoptions['constraints'] = array(new Assert\Length(array('min' => 10))
                                 ,new Assert\Regex(array(
                                     'pattern' => '/^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&amp;*-]).{10,}$/',
                                     'match'=>true,
                                     'message'=>'Password must contain atleast 1 special character 1 upper case letter 1 number and 1 lower case letter !'))
                                 );
         } else {
            $passwordoptions['required'] = true;
            $passwordoptions['constraints'] = array(new Assert\Length(array('min' => 10))
                                ,new Assert\Regex(array(
                                    'pattern' => '/^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&amp;*-]).{10,}$/',
                                    'match'=>true,
                                    'message'=>'Password must contain atleast 1 special character 1 upper case letter 1 number and 1 lower case letter !'))
                                );
         }
         
        $formMapper
                ->add('name', 'text', array('label' => 'Real Name'))
                ->add('username', 'text', array('label' => 'Login'))
                ->add('email', 'text', array('label' => 'E-mail'))
                ->add('enabled', CheckboxType::class, array('label' => 'User is enabled ?'))
                ->add('password', 'repeated', $passwordoptions) /*you can add your other fields =P */
                ->add('locked', CheckboxType::class, array('label' => 'User is just LOCKed ?'))
                ;
    }
    
    protected function configureDatagridFilters(DatagridMapper $datagridMapper)
    {//die("datagridMapper");//  after  -  blog/category/list
        $datagridMapper
                ->add('id', null, array('label' => 'user ID'))
                ->add('name', null, array('label' => 'Real Name'))
                ->add('username', null, array('label' => 'Login'))
                ->add('email', null, array('label' => 'E-mail'))
                ->add('enabled', null, array('label' => 'Enabled users'))
                ->add('locked', null, array('label' => 'Locked users'))
                ;
    }

    protected function configureListFields(ListMapper $listMapper)
    {//die("listMapper");// blog/category/list
        
        $listMapper->addIdentifier('name', 'text', array('label' => 'Username'))
                ->addIdentifier('username', 'text', array('label' => 'Login'))
                ->addIdentifier('email', 'text', array('label' => 'E-mail'))
                ->addIdentifier('last_login', 'datetime', array(
                    'format' => 'd/m/Y H:i',
                    'label' => 'Last Login'))
                ->addIdentifier('enabled', 'boolean', array('label' => 'Enabled'))
                ->addIdentifier('locked', 'boolean', array('label' => 'Locked'))
                ->addIdentifier('roles', 'array', array('label' => 'Roles'))
                ;
    }
//  possible types: in ->add*(cel_from_entyty, type, array_options)
//    boolean,
//    datetime,
//    decimal,
//    identifier,
//    integer,
//    many_to_one,
//    string,
//    text,
//    date,
//    time,
//    array.
    
    
}