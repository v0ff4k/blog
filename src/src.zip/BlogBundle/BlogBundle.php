<?php

namespace BlogBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class BlogBundle extends Bundle{

   
	function __construct(){ 
		//echo "<!-- /home/vladimir/www/sf2projects/test/src/AppBundle/AppBundle.php runs -->";
		}

    public function getParent() {
        return 'FOSUserBundle';
    } 
                
}
