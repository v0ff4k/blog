<?php namespace BlogBundle\Controller;

use Symfony\Component\HttpFoundation\Request;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Method;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use BlogBundle\Entity\Blog;
use BlogBundle\Entity\Category;
use BlogBundle\Entity\Comment;
use BlogBundle\Form\BlogType;

/**
 * Blog controller.
 *
 * @Route("/blog")
 */
class BlogController extends Controller
{

    /**
     * Lists all Blog entities.
     *
     * @Route("/", name="blog_index")
     * @Method("GET")
     */
    public function indexAction(Request $page)
    {
        $em = $this->getDoctrine()->getManager();
        $total_posts = $em->getRepository('BlogBundle:Blog')->findBy(array('draft' => 0));

        $page = $page->query->getAlnum('page'); //get alphanum page val from query !
        if (isset($page) && $page > 0) {/* norm $page */
        } else {
            $page = 1;
        }
        $limit = 5;
        $maxPages = ceil(count($total_posts) / $limit);
        $thisPage = $page;

        $blogs = $em->getRepository('BlogBundle:Blog')->findBy(
            array('draft' => 0), //search criteria, as usual, not draft
            array(/* orderBy criteria if needed, else empty array */), $limit, // limit
            $limit * ($thisPage - 1) // offset
        );

        return $this->render('blog/index.html.twig', array(
                'blogs' => $blogs,
                'page' => $page,
                'maxPages' => $maxPages,
                'thisPage' => $thisPage,
        ));
    }

    /**
     * Creates a new Blog entity.
     *
     * @Route("/new", name="blog_new")
     * @Method({"GET", "POST"})
     */
    public function newAction(Request $request)
    {
        $blog = new Blog();
        $user = $this->getUser();
        $blog->setPostAuthor($user);

        $blog->setDraft('1');

        $form = $this->createForm('BlogBundle\Form\BlogType', $blog);
        //dump($request);die();
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $em = $this->getDoctrine()->getManager();
            $em->persist($blog);
            $em->flush();

            return $this->redirectToRoute('blog_show', array('id' => $blog->getId()));
        }

        return $this->render('blog/new.html.twig', array(
                'blog' => $blog,
                'form' => $form->createView(),
            ));
    }

    /**
     * Finds and displays a Blog entity.
     *
     * @Route("/{id}", name="blog_show", requirements={"id": "\d+"})
     * @Method("GET")
     */
    public function showAction(Blog $blog)
    {
        $em = $this->getDoctrine()->getManager();

        // getCommentBlog()  by blog id 
        $comments = $em->getRepository('BlogBundle:Comment')
            ->findBy(array('comment_blog' => $blog->getId()));
        // return all where  comment.commentBlog.id == blog.id
        ////todo redirect user to all blogs if  404 for id
        $deleteForm = $this->createDeleteForm($blog);

        return $this->render('blog/show.html.twig', array(
                'blog' => $blog,
                'delete_form' => $deleteForm->createView(),
                'comments' => $comments,
        ));
    }

    /**
     * Displays a form to edit an existing Blog entity.
     *
     * @Route("/{id}/edit", name="blog_edit", requirements={"id": "\d+"})
     * @Method({"GET", "POST"})
     */
    public function editAction(Request $request, Blog $blog)
    {

        ////todo redirect user to all blogs if  404 for id
        $deleteForm = $this->createDeleteForm($blog);
        $editForm = $this->createForm('BlogBundle\Form\BlogType', $blog);
        $editForm->handleRequest($request);

        if ($editForm->isSubmitted() && $editForm->isValid()) {
            $em = $this->getDoctrine()->getManager();
            $em->persist($blog);
            $em->flush();

            return $this->redirectToRoute('blog_index');
        }

        return $this->render('blog/edit.html.twig', array(
                'blog' => $blog,
                'edit_form' => $editForm->createView(),
                'delete_form' => $deleteForm->createView(),
        ));
    }

    /**
     * Deletes a Blog entity.
     *
     * @Route("/{id}", name="blog_delete", requirements={"id": "\d+"})
     * @Method("DELETE")
     */
    public function deleteAction(Request $request, Blog $blog)
    {
        $form = $this->createDeleteForm($blog);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $em = $this->getDoctrine()->getManager();
            $em->remove($blog);
            $em->flush();
        }

        return $this->redirectToRoute('blog_index');
    }

    /**
     * Creates a form to delete a Blog entity.
     *
     * @param Blog $blog The Blog entity
     *
     * @return \Symfony\Component\Form\Form The form
     */
    private function createDeleteForm(Blog $blog)
    {
        return $this->createFormBuilder()
                ->setAction($this->generateUrl('blog_delete', array('id' => $blog->getId())))
                ->setMethod('DELETE')
                ->getForm()
        ;
    }
}
