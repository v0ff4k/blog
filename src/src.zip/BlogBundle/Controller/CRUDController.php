<?php
// src/BlogBundle/Controller/CRUDController.php
namespace BlogBundle\Controller;

use Sonata\AdminBundle\Controller\CRUDController as BaseController;
use Sonata\AdminBundle\Datagrid\ProxyQueryInterface;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\Security\Core\Exception\AccessDeniedException;
use BlogBundle\Entity\Blog;

class CRUDController extends BaseController
{

    //publish current post  are in //src/BlogBundle/Controller/Publish.php
    public function publishAction(Blog $post)// edit()
    {
        //dump($post->getDraft());die("ACTION !!!!!!!!!!!!!!!!!!!!!!!"); 
        if ($post->getDraft()) { //if post is a draft - so make them undraft
            $em = $this->getDoctrine()->getManager();
            $post->setDraft('0');
            $em->persist($post);
            $em->flush();
        }


        return new RedirectResponse(
            $this->admin->generateUrl('list', array('filter' => $this->admin->getFilterParameters()))
        );
    }

    /**
     * @param ProxyQueryInterface $selectedModelQuery
     * @param Request             $request
     *
     * @return RedirectResponse
     */
    public function batchActionPublish(ProxyQueryInterface $selectedModelQuery, Request $request = null)
    {
        if (!$this->admin->isGranted('EDIT') || !$this->admin->isGranted('DELETE')) {
            throw new AccessDeniedException();
        }

        $em = $this->getDoctrine()->getManager();

        foreach ($selectedModelQuery->execute() as $posts) {

            if ($posts->getDraft()) { //if post is a draft - so make them undraft
                $posts->setDraft('0');
                $em->persist($posts);
            }
        }

        $em->flush();

        return new RedirectResponse(
            $this->admin->generateUrl('list', array('filter' => $this->admin->getFilterParameters()))
        );
    }

    /**
     * @param ProxyQueryInterface $selectedModelQuery
     *
     * @return RedirectResponse
     */
    public function batchActionDrafter(ProxyQueryInterface $selectedModelQuery)
    {
        if (!$this->admin->isGranted('EDIT') || !$this->admin->isGranted('DELETE')) {
            throw new AccessDeniedException();
        }

        $em = $this->getDoctrine()->getManager();

        foreach ($selectedModelQuery->execute() as $posts) {

            if (!$posts->getDraft()) { //if post is not a draft - so make them undraft
                $posts->setDraft('1');
                $em->persist($posts);
            }
        }

        $em->flush();

        return new RedirectResponse(
            $this->admin->generateUrl('list', array('filter' => $this->admin->getFilterParameters()))
        );
    }
    // ...
}
