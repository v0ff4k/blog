<?php namespace BlogBundle\Controller;

use Symfony\Component\HttpFoundation\Request;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Method;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use BlogBundle\Entity\Category;
use BlogBundle\Entity\Blog;
use BlogBundle\Form\CategoryType;

/**
 * Category controller.
 *
 * @Route("/category")
 */
class CategoryController extends Controller
{

    /**
     * Lists all Category entities.
     *
     * @Route("/", name="category_index")
     * @Method("GET")
     */
    public function indexAction()
    {
        $em = $this->getDoctrine()->getManager();

        $categories = $em->getRepository('BlogBundle:Category')->findAll();

        return $this->render('category/index.html.twig', array(
                'categories' => $categories,
        ));
    }

    /**
     * Creates a new Category entity.
     *
     * @Route("/new", name="category_new")
     * @Method({"GET", "POST"})
     */
    public function newAction(Request $request)
    {
        $category = new Category();
        $form = $this->createForm('BlogBundle\Form\CategoryType', $category);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $em = $this->getDoctrine()->getManager();
            $em->persist($category);
            $em->flush();

            return $this->redirectToRoute('category_index');
            //return $this->redirectToRoute('category_show', array('id' => $category->getId()));
        }

        return $this->render('category/new.html.twig', array(
                'category' => $category,
                'form' => $form->createView(),
        ));
    }

    /**     * *************************************************************
     * Find POSTs by specific cat and displays a Category entity.
     *
     * @Route("/{id}", name="category_show")
     * @Method("GET")
     */
    public function showAction(Category $category, Request $page)
    {
        $em = $this->getDoctrine()->getManager();
        $total_posts = $em->getRepository('BlogBundle:Blog')->findBy(
            array('draft' => 0,
                'post_category' => $category->getId()
        ));

        //dump($total_posts);die();
        $page = $page->query->getAlnum('page');
        if (isset($page) && $page > 0) {/* norm $page */
        } else {
            $page = 1;
        }
        $limit = 5;
        $maxPages = round(count($total_posts) / $limit);
        $thisPage = $page;

        $blogs = $em->getRepository('BlogBundle:Blog')->findBy(
            array('draft' => 0, //search criteria, as usual, not draft
            'post_category' => $category->getId()), //and for current category
            array(/* orderBy criteria if needed, else empty array */), $limit, // limit
            $limit * ($thisPage - 1) // offset
        );



        $deleteForm = $this->createDeleteForm($category);
        return $this->render('category/show.html.twig', array(
                'blogs' => $blogs,
                'page' => $page,
                'maxPages' => $maxPages,
                'thisPage' => $thisPage, // end for posts by category
                'category' => $category,
                'delete_form' => $deleteForm->createView(),
        ));
    }

    /**
     * Displays a form to edit an existing Category entity.
     *
     * @Route("/{id}/edit", name="category_edit")
     * @Method({"GET", "POST"})
     */
    public function editAction(Request $request, Category $category)
    {
        $deleteForm = $this->createDeleteForm($category);
        $editForm = $this->createForm('BlogBundle\Form\CategoryType', $category);
        $editForm->handleRequest($request);

        if ($editForm->isSubmitted() && $editForm->isValid()) {
            $em = $this->getDoctrine()->getManager();
            $em->persist($category);
            $em->flush();

            return $this->redirectToRoute('category_index');
            //return $this->redirectToRoute('category_edit', array('id' => $category->getId()));
        }

        return $this->render('category/edit.html.twig', array(
                'category' => $category,
                'edit_form' => $editForm->createView(),
                'delete_form' => $deleteForm->createView(),
        ));
    }

    /**
     * Deletes a Category entity.
     *
     * @Route("/{id}", name="category_delete")
     * @Method("DELETE")
     */
    public function deleteAction(Request $request, Category $category)
    {
        $form = $this->createDeleteForm($category);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $em = $this->getDoctrine()->getManager();
            $em->remove($category);
            $em->flush();
        }

        return $this->redirectToRoute('category_index');
    }

    /**
     * Creates a form to delete a Category entity.
     *
     * @param Category $category The Category entity
     *
     * @return \Symfony\Component\Form\Form The form
     */
    private function createDeleteForm(Category $category)
    {
        return $this->createFormBuilder()
                ->setAction($this->generateUrl('category_delete', array('id' => $category->getId())))
                ->setMethod('DELETE')
                ->getForm()
        ;
    }
}
