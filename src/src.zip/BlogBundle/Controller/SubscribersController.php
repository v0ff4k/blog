<?php namespace BlogBundle\Controller;

use BlogBundle\Entity\Subscribers;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Method;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Symfony\Component\HttpFoundation\Request;

/**
 * Subscriber controller.
 *
 * @Route("/subscribe")
 */
class SubscribersController extends Controller
{

    /**
     * Creates a new subscriber entity.
     *
     * @Route("/", name="subscribe_now")
     * @Method({"GET", "POST"})
     */
    public function indexAction(Request $request)
    {
        $subs = new Subscribers();
        $user = $this->getUser();

        if ($user) {//user are currenly login and exist
            $subscriber_name = $this->getUser()->getName(); //get username if user registred(check with anonimous)
            $subscriber_mail = $this->getUser()->getEmail();

            //dump($this->getUser()->email);die;

            $subs->setSubscriber($subscriber_name); //set name of subscriber
            $subs->setEmail($subscriber_mail); //set name of subscriber
        }

        $form = $this->createForm('BlogBundle\Form\SubscribersType', $subs);
        $form->handleRequest($request);


        if ($form->isSubmitted() && $form->isValid()) {
            $subscriber = $form->getData();
            $em = $this->getDoctrine()->getManager();

            $em->persist($subscriber);
            $em->flush($subscriber);

            return $this->render(
                    'subscribe/done.html.twig', array('subscriber' => $subscriber)//add name+mail to display.
            );
        }

        return $this->render('subscribe/index.html.twig', array(
                'form' => $form->createView(),
        ));
    }
}
