<?php

// src/BlogBundle/Entity/Blog.php

namespace BlogBundle\Entity;


use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Validator\Constraints as Assert;

/**
 * @ORM\Entity
 * @ORM\Table(name="blog_posts")
 */
class Blog
{

    /**
     * @ORM\Id
     * @ORM\Column(type="integer")
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    protected $id;


    /**
     * @ORM\ManyToOne(targetEntity="User", inversedBy="blog_post")
     * @ORM\JoinColumn(name="post_author", referencedColumnName="id")
     */
    protected $post_author;

 
    /**
     * @ORM\OneToMany(targetEntity="Comment", mappedBy="comment_blog")
     */
    protected $post_comment;
    
    
    /**
     * @ORM\ManyToOne(targetEntity="Category", inversedBy="category_blog")
     * @ORM\JoinColumn(name="post_category", referencedColumnName="id")
     */
    protected $post_category;    

    
    /**
     * @ORM\Column(type="datetime", name="posted_at", nullable=false)
     */
    protected $postDate;
    
    
    /**
     * @ORM\Column(type="string", length=128)
     */
    protected $tags;

    
    /**
     * @ORM\Column(type="string")
     */
    protected $title;
    
    /**
     * @ORM\Column(type="text")
     */
    protected $blog_content;


    /**
     * @ORM\Column(name="draft", type="boolean", nullable=false)
     */
     protected $draft = 1;

 
    
    /**
     * Constructor
     */
    public function __construct()
    {
        $this->post_comment = new \Doctrine\Common\Collections\ArrayCollection();
        $this->postDate = new \DateTime();
    }

    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set postDate
     *
     * @param \DateTime $postDate
     *
     * @return Blog
     */
    public function setPostDate($postDate)
    {
        $this->postDate = $postDate;

        return $this;
    }

    /**
     * Get postDate
     *
     * @return \DateTime
     */
    public function getPostDate()
    {
        return $this->postDate;
    }

    /**
     * Set tags
     *
     * @param string $tags
     *
     * @return Blog
     */
    public function setTags($tags)
    {
        $this->tags = $tags;

        return $this;
    }

    /**
     * Get tags
     *
     * @return string
     */
    public function getTags()
    {
        return $this->tags;
    }

    /**
     * Set title
     *
     * @param string $title
     *
     * @return Blog
     */
    public function setTitle($title)
    {
        $this->title = $title;

        return $this;
    }

    /**
     * Get title
     *
     * @return string
     */
    public function getTitle()
    {
        return $this->title;
    }

    /**
     * Set blogContent
     *
     * @param string $blogContent
     *
     * @return Blog
     */
    public function setBlogContent($blogContent)
    {
        $this->blog_content = $blogContent;

        return $this;
    }

    /**
     * Get blogContent
     *
     * @return string
     */
    public function getBlogContent()
    {
        return $this->blog_content;
    }

    /**
     * Set postAuthor
     *
     * @param \BlogBundle\Entity\User $postAuthor
     *
     * @return Blog
     */
    public function setPostAuthor(\BlogBundle\Entity\User $postAuthor = null)
    {
        $this->post_author = $postAuthor;

        return $this;
    }

    /**
     * Get postAuthor
     *
     * @return \BlogBundle\Entity\User
     */
    public function getPostAuthor()
    {
        return $this->post_author;
    }

    /**
     * Add postComment
     *
     * @param \BlogBundle\Entity\Comment $postComment
     *
     * @return Blog
     */
    public function addPostComment(\BlogBundle\Entity\Comment $postComment)
    {
        $this->post_comment[] = $postComment;

        return $this;
    }

    /**
     * Remove postComment
     *
     * @param \BlogBundle\Entity\Comment $postComment
     */
    public function removePostComment(\BlogBundle\Entity\Comment $postComment)
    {
        $this->post_comment->removeElement($postComment);
    }

    /**
     * Get postComment
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getPostComment()
    {
        return $this->post_comment;
    }

    /**
     * Set postCategory
     *
     * @param \BlogBundle\Entity\Category $postCategory
     *
     * @return Blog
     */
    public function setPostCategory(\BlogBundle\Entity\Category $postCategory = null)
    {
        $this->post_category = $postCategory;

        return $this;
    }

    /**
     * Get postCategory
     *
     * @return \BlogBundle\Entity\Category
     */
    public function getPostCategory()
    {
        return $this->post_category;
    }
    
    
    
    
    public function setDraft($boolean)
    {
        $this->draft = $boolean;

        return $this;
    }

    /**
     * Gets the draft state.
     *
     * @param Boolean $boolean
     *
     * @return Blog
     */
    
    public function getDraft()
    {
        return $this->draft;
    }

    
    public function __toString()
    {
        return $this->title;
    }
    
    
}
