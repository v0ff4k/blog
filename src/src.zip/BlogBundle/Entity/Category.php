<?php

// src/BlogBundle/Entity/Category.php

namespace BlogBundle\Entity;


use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Validator\Constraints as Assert;

/**
 * @ORM\Entity
 * @ORM\Table(name="blog_categories")
 */
class Category
{

    /**
     * @ORM\Id
     * @ORM\Column(type="integer")
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    protected $id;

    /**
     * @var string $category_name
     *
     * @ORM\Column(name="category_name", type="string", length=128, unique=true)
     * in future think abouit A-s-s-e-r-t\ 
     */    
    protected $category_name;
    

    /**
     * @ORM\OneToMany(targetEntity="Blog", mappedBy="post_category")
     */
    protected $category_blog;


    /**
     * Constructor
     */
    public function __construct()
    {
        $this->category_blog = new \Doctrine\Common\Collections\ArrayCollection();
    }

    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set categoryName
     *
     * @param string $categoryName
     *
     * @return Category
     */
    public function setCategoryName($categoryName)
    {
        $this->category_name = $categoryName;

        return $this;
    }

    /**
     * Get categoryName
     *
     * @return string
     */
    public function getCategoryName()
    {
        return $this->category_name;
    }

    /**
     * Add categoryBlog
     *
     * @param \BlogBundle\Entity\Blog $categoryBlog
     *
     * @return Category
     */
    public function addCategoryBlog(\BlogBundle\Entity\Blog $categoryBlog)
    {
        $this->category_blog[] = $categoryBlog;

        return $this;
    }

    /**
     * Remove categoryBlog
     *
     * @param \BlogBundle\Entity\Blog $categoryBlog
     */
    public function removeCategoryBlog(\BlogBundle\Entity\Blog $categoryBlog)
    {
        $this->category_blog->removeElement($categoryBlog);
    }

    /**
     * Get categoryBlog
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getCategoryBlog()
    {
        return $this->category_blog;
    }
    
    
    public function __toString() {
        return $this->category_name;
    }
    
}
