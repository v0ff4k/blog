<?php

// src src/BlogBundle/Entity/Comment.php

namespace BlogBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Validator\Constraints as Assert;

/**
 * @ORM\Entity
 * @ORM\Table(name="blog_comments")
 */
class Comment
{

    /**
     * @ORM\Id
     * @ORM\Column(type="integer")
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    protected $id;

    /** 
     * @ORM\ManyToOne(targetEntity="User", inversedBy="blog_comment")
     * @ORM\JoinColumn(name="comment_author", referencedColumnName="id")
     */
    protected $comment_author;
    
    
    /** 
     * @ORM\ManyToOne(targetEntity="Blog", inversedBy="post_comment")
     * @ORM\JoinColumn(name="comment_blog", referencedColumnName="id")
     */
    protected $comment_blog;
    
    

    /**
     * @ORM\Column(name="commented_at", type="datetime", nullable=false)
     */
    protected $postDate;  
    
    
    /**
     * @ORM\Column(type="text")
     */
    protected $comment_content;
    
    
    
     /**
     * Constructor
     */
    public function __construct()
    {
    //    $this->post_comment = new \Doctrine\Common\Collections\ArrayCollection();
        $this->postDate = new \DateTime();
    }

    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set postDate
     *
     * @param \DateTime $postDate
     *
     * @return Comment
     */
    public function setPostDate($postDate)
    {
        $this->postDate = $postDate;

        return $this;
    }

    /**
     * Get postDate
     *
     * @return \DateTime
     */
    public function getPostDate()
    {
        return $this->postDate;
    }

    /**
     * Set commentContent
     *
     * @param string $commentContent
     *
     * @return Comment
     */
    public function setCommentContent($commentContent)
    {
        $this->comment_content = $commentContent;

        return $this;
    }

    /**
     * Get commentContent
     *
     * @return string
     */
    public function getCommentContent()
    {
        return $this->comment_content;
    }

    /**
     * Set commentAuthor
     *
     * @param \BlogBundle\Entity\User $commentAuthor
     *
     * @return Comment
     */
    public function setCommentAuthor(\BlogBundle\Entity\User $commentAuthor = null)
    {
        $this->comment_author = $commentAuthor;

        return $this;
    }

    /**
     * Get commentAuthor
     *
     * @return \BlogBundle\Entity\User
     */
    public function getCommentAuthor()
    {
        return $this->comment_author;
    }

    /**
     * Set commentBlog
     *
     * @param \BlogBundle\Entity\Blog $commentBlog
     *
     * @return Comment
     */
    public function setCommentBlog(\BlogBundle\Entity\Blog $commentBlog = null)
    {
        $this->comment_blog = $commentBlog;

        return $this;
    }

    /**
     * Get commentBlog
     *
     * @return \BlogBundle\Entity\Blog
     */
    public function getCommentBlog()
    {
        return $this->comment_blog;
    }
 
    
 }
