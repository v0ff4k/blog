<?php

// src/BlogBundle/Entity/Subscribers.php

namespace BlogBundle\Entity;


use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Validator\Constraints as Assert;

use Symfony\Bridge\Doctrine\Validator\Constraints\UniqueEntity;

/**
 * @ORM\Entity
 * @UniqueEntity(fields ="email", message ="This e-mail is already in use! Please check your e-mail, you are already in subscribed list.")
 * @ORM\Table(name="blog_subscribers")
 */
class Subscribers
{
    /**
     * @ORM\Id
     * @ORM\Column(type="integer")
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    protected $id;


    /**
     * @ORM\Column(name="name", type="string", length=128)
     */
    protected $subscriber;
    
    /**
     * @ORM\Column(name="email", type="string", length=255, unique=true)
     * @Assert\NotBlank(message="Please enter your email.", groups={"Registration", "Profile"})
     */
    protected $email;

    /**
     * @ORM\Column(type="datetime", name="subscribed", nullable=false)
     */    
    protected $subscribed;


    
    public function __construct()
    {
//        parent::__construct();
        // your own logic
        
        //set current time for subscrcribe
        $this->subscribed = new \DateTime();
   }
    

    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set subscriber
     *
     * @param string $subscriber
     *
     * @return Subscribers
     */
    public function setSubscriber($subscriber)
    {
        $this->subscriber = $subscriber;

        return $this;
    }

    /**
     * Get subscriber
     *
     * @return string
     */
    public function getSubscriber()
    {
        return $this->subscriber;
    }

    /**
     * Set email
     *
     * @param string $email
     *
     * @return Subscribers
     */
    public function setEmail($email)
    {
        $this->email = $email;

        return $this;
    }

    /**
     * Get email
     *
     * @return string
     */
    public function getEmail()
    {
        return $this->email;
    }

    /**
     * Set subscribed
     *
     * @param \DateTime $subscribed
     *
     * @return Subscribers
     */
    public function setSubscribed($subscribed)
    {
        $this->subscribed = $subscribed;

        return $this;
    }

    /**
     * Get subscribed
     *
     * @return \DateTime
     */
    public function getSubscribed()
    {
        return $this->subscribed;
    }

    
    public function __toString()
    {
        return (string) $this->getSubscriber();
    }
    
}
