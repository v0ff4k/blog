<?php

// src src/BlogBundle/Entity/User.php

namespace BlogBundle\Entity;

use FOS\UserBundle\Entity\User as BaseUser;
use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Validator\Constraints as Assert;

/**
 * @ORM\Entity
 * @ORM\Table(name="blog_users")
 */
class User extends BaseUser
{
    /**
     * @ORM\Id
     * @ORM\Column(type="integer")
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    protected $id;


    /**
     * @ORM\OneToMany(targetEntity="Blog", mappedBy="post_author")
     */
    protected $blog_post;

    
    /**
     * @ORM\OneToMany(targetEntity="Comment", mappedBy="comment_author")
     */
    protected $blog_comment;
    
    
    /**
     * @ORM\Column(type="string", length=255)
     *
     * @Assert\NotBlank(message="Please enter your name.", groups={"Registration", "Profile"})
     * @Assert\Length(
     *     min=3,
     *     max=255,
     *     minMessage="The name is too short.",
     *     maxMessage="The name is too long.",
     *     groups={"Registration", "Profile"}
     * )
     */
    protected $name;
    
    
    public function __construct()
    {
        parent::__construct();
        // your own logic
        
//        from original      
//        $this->salt = base_convert(sha1(uniqid(mt_rand(), true)), 16, 36);
//        $this->enabled = false;
//        $this->locked = false;
//        $this->expired = false;
//        $this->roles = array();
//        $this->credentialsExpired = false;
    }

    /**
     * Set name
     *
     * @param string $name
     *
     * @return User
     */
    public function setName($name)
    {
        $this->name = $name;

        return $this;
    }

    /**
     * Get name
     *
     * @return string
     */
    public function getName()
    {
        return $this->name;
    }

    /**
     * Add blogPost
     *
     * @param \BlogBundle\Entity\Blog $blogPost
     *
     * @return User
     */
    public function addBlogPost(\BlogBundle\Entity\Blog $blogPost)
    {
        $this->blog_post[] = $blogPost;

        return $this;
    }

    /**
     * Remove blogPost
     *
     * @param \BlogBundle\Entity\Blog $blogPost
     */
    public function removeBlogPost(\BlogBundle\Entity\Blog $blogPost)
    {
        $this->blog_post->removeElement($blogPost);
    }

    /**
     * Get blogPost
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getBlogPost()
    {
        return $this->blog_post;
    }

    /**
     * Add blogComment
     *
     * @param \BlogBundle\Entity\Comment $blogComment
     *
     * @return User
     */
    public function addBlogComment(\BlogBundle\Entity\Comment $blogComment)
    {
        $this->blog_comment[] = $blogComment;

        return $this;
    }

    /**
     * Remove blogComment
     *
     * @param \BlogBundle\Entity\Comment $blogComment
     */
    public function removeBlogComment(\BlogBundle\Entity\Comment $blogComment)
    {
        $this->blog_comment->removeElement($blogComment);
    }

    /**
     * Get blogComment
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getBlogComment()
    {
        return $this->blog_comment;
    }

    
   public function __toString()
    {
        return (string) $this->getName();
    }
    
}