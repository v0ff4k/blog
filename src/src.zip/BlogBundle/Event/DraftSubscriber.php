<?php // src/BlogBundle/Event/SearchIndexer.php
namespace BlogBundle\Event;

use Doctrine\Common\EventSubscriber;
use Doctrine\ORM\Event\PreUpdateEventArgs;
use BlogBundle\Entity\Blog;

use Symfony\Component\DependencyInjection\ContainerInterface;

class DraftSubscriber implements EventSubscriber
{
    protected $container;

    public function __construct(ContainerInterface $container )
    {
        $this->container = $container;
    } 
    
    public function getSubscribedEvents() {
        return array(
            'preUpdate'
            );
    }

    public function preUpdate(PreUpdateEventArgs $args)
    { //die("!!!!!!!!!!!!!!!!!!!!!!!!!!!");
        $entity = $args->getEntity();//gets new Blog()
        $em = $args->getEntityManager();//gets users

        // only act on some "Blog" entity
        if ($entity instanceof Blog) {
           
            if($args->hasChangedField('draft') && $args->getNewValue('draft') == 0 ){
                
                $all_users = $em->getRepository('BlogBundle:Subscribers')->findAll();
                
                //dump($args);die("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
                
                foreach ($all_users as $val) {
                    
                    $this->container->get('app.mailer')->SendMail( $val->getSubscriber(), $val->getEmail(), $entity->getTitle() );
                }
                
            }

        }//end if ($entity instanceof Blog) 
        
    }
}