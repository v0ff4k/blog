<?php
// src/BlogBundle/Form/ProfileType.php

namespace BlogBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Form\Extension\Core\Type\TextType;

use Symfony\Component\Security\Core\Validator\Constraint\UserPassword as OldUserPassword;
use Symfony\Component\Security\Core\Validator\Constraints\UserPassword;


use FOS\UserBundle\Util\LegacyFormHelper;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\OptionsResolver\OptionsResolverInterface;

class ChangePasswordType extends AbstractType
{ 
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        if (class_exists('Symfony\Component\Security\Core\Validator\Constraints\UserPassword')) {
            $constraint = new UserPassword();
        } else {
            // Symfony 2.1 support with the old constraint class
            $constraint = new OldUserPassword();
        }

        $builder
                ->add('current_password', 'password', array(
            'label' => 'Current Pass',
            'translation_domain' => 'BlogBundle',
            'mapped' => false,
            'constraints' => $constraint,
        ))
                ->add('new', 'repeated', array(
            'type' => 'password',
            'options' => array('translation_domain' => 'BlogBundle'),
            'first_options' => array('label' => 'New password'),
            'second_options' => array('label' => 'Repeat new password'),
            'invalid_message' => 'Passwords are mismatch',
        ));
    }
    

    public function getParent(){
        
        return 'FOS\UserBundle\Form\Type\ChangePasswordFormType';
    }

    public function getBlockPrefix(){
        
        return 'app_user_change_password';
    }

    // For Symfony 2.x
    public function getName()
    {
        return $this->getBlockPrefix();
    }

   
}