<?php //src/BlogBundle/Mailer.php

namespace BlogBundle;


class Mailer
{
    protected $mailer;
    protected $twig;

    public function __construct(\Swift_Mailer $mailer, \Twig_Environment $twig)
    {
        $this->mailer = $mailer;
        $this->twig = $twig;
    }    
     
    public function SendMail($name_reciepent, $email_reciepent, $post_subject)
    {
        //dump($this->mailer);die("eventaction work !!! ##################################");
        
        $mail_subject = "New post is waiting for you !";//todo - add var in config !
        $sender = "admin@blog.server.com";//todo - add var in config !
        $reciepent = $email_reciepent;
        $body = $this->renderTemplate($name_reciepent, $post_subject);

        
        $mail = \Swift_Message::newInstance()
            ->setSubject($mail_subject)
            ->setFrom($sender)
            ->setTo($reciepent)
            ->setBody($body);


        //send mail  (in config it stores in flatfile !!!)
         //dump( $this->mailer );die("mail has been \"send\" *******************************");
        
        $this->mailer->send($mail);


    }//end public function __construct()
    
    
    public function renderTemplate($some_user, $post_subject)
    {//don't use TWIG !!! or it will run Circular reference detected for service "security.authentication.manager", 
    //path: "security.firewall.map.context.main -> security.authentication.manager -> ... 
    // -> draft.listener -> twig -> security.authorization_checker". 
        
//        return "New post awaiting you !!!";
        return $this->twig->render(
            'BlogBundle:email:newsmail.html.twig', array(
                'name' => $some_user, 
                'subject' => $post_subject
                )
        );
    }
 
}//end class Mailer