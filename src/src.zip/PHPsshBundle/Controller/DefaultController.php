<?php namespace PHPsshBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Symfony\Component\HttpFoundation\Request;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Method;
use BlogBundle\Entity\User;
use Sinner\Phpseclib\Crypt\Crypt_TripleDES as TripleDES;

/**
 * Blog controller.
 *
 * @Route("/ssh")
 */
class DefaultController extends Controller
{

    /**
     * Blog controller.
     * 
     * @Route("/", name="homessh")
     * @Method("GET")
     */
    public function indexAction()
    {

        $sshUser = new \stdClass;
        $sshUser->id = 1;
        $sshUser->nombre = 'Jos&eacute; Gabriel';
        $sshUser->apellido = 'Gonz&aacute;lez P&eacute;rez';
        $sshUser->email = 'jgabrielsinner10@gmail.com';
        $sshUser->twitter = '@JGabrielTupac';

        $key = '548c286a61462d896573567b7a30335d4959427e5c7a675e325b6c7a7c';

        $_KEY_ENCRYPT = KEY_ENCRYPT;

        $encrypter = new TripleDES();
        $encrypter->setKey($key);
        $usuario_obj_encrypt = $encrypter->encrypt(serialize($sshUser));
        $usuario = unserialize($encrypter->decrypt($usuario_obj_encrypt));


        return $this->render('PHPsshBundle:Default:index.html.twig');
    }
}
