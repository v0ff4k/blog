<?php

namespace PHPsshBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class PHPsshBundle extends Bundle
{
}
